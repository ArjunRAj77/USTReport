package Login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StudentInfo  extends HttpServlet{
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		
		String user = req.getParameter("userName");
		String password = req.getParameter("userPassword");
		
		if(user.equals("student")&&password.equals("login")
				) {
			pw.println("*******************************");
			pw.println("Login successfull");
			pw.println("*******************************");
		}
		else
		{
			pw.println("*******************************");
			pw.println("Login failed");
			pw.println("*******************************");
		}pw.close();
		
		
	}
	
	

}
